/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/20816/Desktop/treasure_chest/computer_organization/ISE/P8/P8_counter/CP0.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {63U, 0U};
static unsigned int ng3[] = {85988116U, 0U};
static int ng4[] = {1, 0};
static unsigned int ng5[] = {12U, 0U};
static unsigned int ng6[] = {14U, 0U};
static unsigned int ng7[] = {0U, 0U};
static unsigned int ng8[] = {4192U, 0U};
static unsigned int ng9[] = {1U, 0U};
static unsigned int ng10[] = {13U, 0U};
static unsigned int ng11[] = {15U, 0U};



static void Initial_35_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(35, ng0);

LAB2:    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2116);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 2208);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 6);
    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2300);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);
    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 2484);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2576);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 6);
    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2668);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 5);
    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2760);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);
    xsi_set_current_line(37, ng0);
    t1 = ((char*)((ng4)));
    t2 = (t0 + 2392);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);

LAB1:    return;
}

static void Always_40_1(char *t0)
{
    char t11[8];
    char t22[8];
    char t63[8];
    char t66[8];
    char t76[8];
    char t84[8];
    char t105[16];
    char t109[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    int t46;
    int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;
    char *t61;
    int t62;
    char *t64;
    char *t65;
    char *t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    char *t75;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    char *t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    char *t94;
    char *t95;
    char *t96;
    int t97;
    unsigned int t98;
    unsigned int t99;
    char *t100;
    char *t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t106;
    char *t107;
    char *t108;
    char *t110;

LAB0:    t1 = (t0 + 3428U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 4056);
    *((int *)t2) = 1;
    t3 = (t0 + 3456);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(40, ng0);

LAB5:    xsi_set_current_line(41, ng0);
    t4 = (t0 + 1152U);
    t5 = *((char **)t4);
    t4 = (t0 + 2576);
    xsi_vlogvar_assign_value(t4, t5, 0, 0, 6);
    xsi_set_current_line(42, ng0);
    t2 = (t0 + 692U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(46, ng0);

LAB10:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 784U);
    t3 = *((char **)t2);
    t2 = (t0 + 876U);
    t4 = *((char **)t2);
    memset(t11, 0, 8);
    t2 = (t4 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB14;

LAB12:    if (*((unsigned int *)t2) == 0)
        goto LAB11;

LAB13:    t5 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t5) = 1;

LAB14:    t12 = (t11 + 4);
    t13 = (t4 + 4);
    t14 = *((unsigned int *)t4);
    t15 = (~(t14));
    *((unsigned int *)t11) = t15;
    *((unsigned int *)t12) = 0;
    if (*((unsigned int *)t13) != 0)
        goto LAB16;

LAB15:    t20 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t20 & 1U);
    t21 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t21 & 1U);
    t23 = *((unsigned int *)t3);
    t24 = *((unsigned int *)t11);
    t25 = (t23 & t24);
    *((unsigned int *)t22) = t25;
    t26 = (t3 + 4);
    t27 = (t11 + 4);
    t28 = (t22 + 4);
    t29 = *((unsigned int *)t26);
    t30 = *((unsigned int *)t27);
    t31 = (t29 | t30);
    *((unsigned int *)t28) = t31;
    t32 = *((unsigned int *)t28);
    t33 = (t32 != 0);
    if (t33 == 1)
        goto LAB17;

LAB18:
LAB19:    t54 = (t22 + 4);
    t55 = *((unsigned int *)t54);
    t56 = (~(t55));
    t57 = *((unsigned int *)t22);
    t58 = (t57 & t56);
    t59 = (t58 != 0);
    if (t59 > 0)
        goto LAB20;

LAB21:    xsi_set_current_line(55, ng0);

LAB30:    xsi_set_current_line(56, ng0);
    t2 = (t0 + 2300);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    memset(t11, 0, 8);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB34;

LAB32:    if (*((unsigned int *)t5) == 0)
        goto LAB31;

LAB33:    t12 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t12) = 1;

LAB34:    t13 = (t11 + 4);
    t26 = (t4 + 4);
    t14 = *((unsigned int *)t4);
    t15 = (~(t14));
    *((unsigned int *)t11) = t15;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t26) != 0)
        goto LAB36;

LAB35:    t20 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t20 & 1U);
    t21 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t21 & 1U);
    t27 = (t0 + 876U);
    t28 = *((char **)t27);
    t27 = (t0 + 1704U);
    t36 = *((char **)t27);
    t23 = *((unsigned int *)t28);
    t24 = *((unsigned int *)t36);
    t25 = (t23 | t24);
    *((unsigned int *)t22) = t25;
    t27 = (t28 + 4);
    t37 = (t36 + 4);
    t54 = (t22 + 4);
    t29 = *((unsigned int *)t27);
    t30 = *((unsigned int *)t37);
    t31 = (t29 | t30);
    *((unsigned int *)t54) = t31;
    t32 = *((unsigned int *)t54);
    t33 = (t32 != 0);
    if (t33 == 1)
        goto LAB37;

LAB38:
LAB39:    t50 = *((unsigned int *)t11);
    t51 = *((unsigned int *)t22);
    t52 = (t50 & t51);
    *((unsigned int *)t63) = t52;
    t65 = (t11 + 4);
    t67 = (t22 + 4);
    t74 = (t63 + 4);
    t53 = *((unsigned int *)t65);
    t55 = *((unsigned int *)t67);
    t56 = (t53 | t55);
    *((unsigned int *)t74) = t56;
    t57 = *((unsigned int *)t74);
    t58 = (t57 != 0);
    if (t58 == 1)
        goto LAB40;

LAB41:
LAB42:    t85 = (t63 + 4);
    t91 = *((unsigned int *)t85);
    t92 = (~(t91));
    t93 = *((unsigned int *)t63);
    t98 = (t93 & t92);
    t99 = (t98 != 0);
    if (t99 > 0)
        goto LAB43;

LAB44:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 968U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB77;

LAB78:
LAB79:
LAB45:
LAB22:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(42, ng0);

LAB9:    xsi_set_current_line(43, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 2116);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2208);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2300);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2484);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2576);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2668);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 5);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2760);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(44, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 2392);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB8;

LAB11:    *((unsigned int *)t11) = 1;
    goto LAB14;

LAB16:    t16 = *((unsigned int *)t11);
    t17 = *((unsigned int *)t13);
    *((unsigned int *)t11) = (t16 | t17);
    t18 = *((unsigned int *)t12);
    t19 = *((unsigned int *)t13);
    *((unsigned int *)t12) = (t18 | t19);
    goto LAB15;

LAB17:    t34 = *((unsigned int *)t22);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t22) = (t34 | t35);
    t36 = (t3 + 4);
    t37 = (t11 + 4);
    t38 = *((unsigned int *)t3);
    t39 = (~(t38));
    t40 = *((unsigned int *)t36);
    t41 = (~(t40));
    t42 = *((unsigned int *)t11);
    t43 = (~(t42));
    t44 = *((unsigned int *)t37);
    t45 = (~(t44));
    t46 = (t39 & t41);
    t47 = (t43 & t45);
    t48 = (~(t46));
    t49 = (~(t47));
    t50 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t50 & t48);
    t51 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t51 & t49);
    t52 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t52 & t48);
    t53 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t53 & t49);
    goto LAB19;

LAB20:    xsi_set_current_line(47, ng0);

LAB23:    xsi_set_current_line(48, ng0);
    t60 = (t0 + 1428U);
    t61 = *((char **)t60);

LAB24:    t60 = ((char*)((ng5)));
    t62 = xsi_vlog_unsigned_case_compare(t61, 5, t60, 5);
    if (t62 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng6)));
    t46 = xsi_vlog_unsigned_case_compare(t61, 5, t2, 5);
    if (t46 == 1)
        goto LAB27;

LAB28:
LAB29:    goto LAB22;

LAB25:    xsi_set_current_line(49, ng0);
    t64 = (t0 + 1520U);
    t65 = *((char **)t64);
    memset(t66, 0, 8);
    t64 = (t66 + 4);
    t67 = (t65 + 4);
    t68 = *((unsigned int *)t65);
    t69 = (t68 >> 0);
    t70 = (t69 & 1);
    *((unsigned int *)t66) = t70;
    t71 = *((unsigned int *)t67);
    t72 = (t71 >> 0);
    t73 = (t72 & 1);
    *((unsigned int *)t64) = t73;
    t74 = (t0 + 1520U);
    t75 = *((char **)t74);
    memset(t76, 0, 8);
    t74 = (t76 + 4);
    t77 = (t75 + 4);
    t78 = *((unsigned int *)t75);
    t79 = (t78 >> 1);
    t80 = (t79 & 1);
    *((unsigned int *)t76) = t80;
    t81 = *((unsigned int *)t77);
    t82 = (t81 >> 1);
    t83 = (t82 & 1);
    *((unsigned int *)t74) = t83;
    t85 = (t0 + 1520U);
    t86 = *((char **)t85);
    memset(t84, 0, 8);
    t85 = (t84 + 4);
    t87 = (t86 + 4);
    t88 = *((unsigned int *)t86);
    t89 = (t88 >> 10);
    *((unsigned int *)t84) = t89;
    t90 = *((unsigned int *)t87);
    t91 = (t90 >> 10);
    *((unsigned int *)t85) = t91;
    t92 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t92 & 63U);
    t93 = *((unsigned int *)t85);
    *((unsigned int *)t85) = (t93 & 63U);
    xsi_vlogtype_concat(t63, 8, 8, 3U, t84, 6, t76, 1, t66, 1);
    t94 = (t0 + 2392);
    xsi_vlogvar_assign_value(t94, t63, 0, 0, 1);
    t95 = (t0 + 2300);
    xsi_vlogvar_assign_value(t95, t63, 1, 0, 1);
    t96 = (t0 + 2208);
    xsi_vlogvar_assign_value(t96, t63, 2, 0, 6);
    goto LAB29;

LAB27:    xsi_set_current_line(50, ng0);
    t3 = ((char*)((ng7)));
    t4 = (t0 + 1520U);
    t5 = *((char **)t4);
    memset(t22, 0, 8);
    t4 = (t22 + 4);
    t12 = (t5 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (t6 >> 2);
    *((unsigned int *)t22) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 2);
    *((unsigned int *)t4) = t9;
    t10 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t10 & 1073741823U);
    t14 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t14 & 1073741823U);
    xsi_vlogtype_concat(t11, 32, 32, 2U, t22, 30, t3, 2);
    t13 = (t0 + 2116);
    xsi_vlogvar_assign_value(t13, t11, 0, 0, 32);
    goto LAB29;

LAB31:    *((unsigned int *)t11) = 1;
    goto LAB34;

LAB36:    t16 = *((unsigned int *)t11);
    t17 = *((unsigned int *)t26);
    *((unsigned int *)t11) = (t16 | t17);
    t18 = *((unsigned int *)t13);
    t19 = *((unsigned int *)t26);
    *((unsigned int *)t13) = (t18 | t19);
    goto LAB35;

LAB37:    t34 = *((unsigned int *)t22);
    t35 = *((unsigned int *)t54);
    *((unsigned int *)t22) = (t34 | t35);
    t60 = (t28 + 4);
    t64 = (t36 + 4);
    t38 = *((unsigned int *)t60);
    t39 = (~(t38));
    t40 = *((unsigned int *)t28);
    t46 = (t40 & t39);
    t41 = *((unsigned int *)t64);
    t42 = (~(t41));
    t43 = *((unsigned int *)t36);
    t47 = (t43 & t42);
    t44 = (~(t46));
    t45 = (~(t47));
    t48 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t48 & t44);
    t49 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t49 & t45);
    goto LAB39;

LAB40:    t59 = *((unsigned int *)t63);
    t68 = *((unsigned int *)t74);
    *((unsigned int *)t63) = (t59 | t68);
    t75 = (t11 + 4);
    t77 = (t22 + 4);
    t69 = *((unsigned int *)t11);
    t70 = (~(t69));
    t71 = *((unsigned int *)t75);
    t72 = (~(t71));
    t73 = *((unsigned int *)t22);
    t78 = (~(t73));
    t79 = *((unsigned int *)t77);
    t80 = (~(t79));
    t62 = (t70 & t72);
    t97 = (t78 & t80);
    t81 = (~(t62));
    t82 = (~(t97));
    t83 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t83 & t81);
    t88 = *((unsigned int *)t74);
    *((unsigned int *)t74) = (t88 & t82);
    t89 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t89 & t81);
    t90 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t90 & t82);
    goto LAB42;

LAB43:    xsi_set_current_line(56, ng0);

LAB46:    xsi_set_current_line(57, ng0);
    t86 = ((char*)((ng4)));
    t87 = (t0 + 2300);
    xsi_vlogvar_assign_value(t87, t86, 0, 0, 1);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 1244U);
    t3 = *((char **)t2);
    t2 = (t0 + 2668);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 5);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 1060U);
    t3 = *((char **)t2);
    t2 = (t0 + 2760);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 1);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 1152U);
    t3 = *((char **)t2);
    t2 = (t0 + 2576);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 6);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 1612U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng7)));
    memset(t11, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t6 = *((unsigned int *)t3);
    t7 = *((unsigned int *)t2);
    t8 = (t6 ^ t7);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t14 = (t9 ^ t10);
    t15 = (t8 | t14);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t5);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB48;

LAB47:    if (t18 != 0)
        goto LAB49;

LAB50:    memset(t22, 0, 8);
    t13 = (t11 + 4);
    t21 = *((unsigned int *)t13);
    t23 = (~(t21));
    t24 = *((unsigned int *)t11);
    t25 = (t24 & t23);
    t29 = (t25 & 1U);
    if (t29 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t13) != 0)
        goto LAB53;

LAB54:    t27 = (t22 + 4);
    t30 = *((unsigned int *)t22);
    t31 = *((unsigned int *)t27);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB55;

LAB56:    memcpy(t84, t22, 8);

LAB57:    t94 = (t84 + 4);
    t89 = *((unsigned int *)t94);
    t90 = (~(t89));
    t91 = *((unsigned int *)t84);
    t92 = (t91 & t90);
    t93 = (t92 != 0);
    if (t93 > 0)
        goto LAB70;

LAB71:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 2116);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 2116);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB72:    goto LAB45;

LAB48:    *((unsigned int *)t11) = 1;
    goto LAB50;

LAB49:    t12 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB50;

LAB51:    *((unsigned int *)t22) = 1;
    goto LAB54;

LAB53:    t26 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t26) = 1;
    goto LAB54;

LAB55:    t28 = (t0 + 1612U);
    t36 = *((char **)t28);
    memset(t63, 0, 8);
    t28 = (t63 + 4);
    t37 = (t36 + 4);
    t33 = *((unsigned int *)t36);
    t34 = (t33 >> 0);
    *((unsigned int *)t63) = t34;
    t35 = *((unsigned int *)t37);
    t38 = (t35 >> 0);
    *((unsigned int *)t28) = t38;
    t39 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t39 & 16383U);
    t40 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t40 & 16383U);
    t54 = ((char*)((ng8)));
    memset(t66, 0, 8);
    t60 = (t63 + 4);
    if (*((unsigned int *)t60) != 0)
        goto LAB59;

LAB58:    t64 = (t54 + 4);
    if (*((unsigned int *)t64) != 0)
        goto LAB59;

LAB62:    if (*((unsigned int *)t63) > *((unsigned int *)t54))
        goto LAB61;

LAB60:    *((unsigned int *)t66) = 1;

LAB61:    memset(t76, 0, 8);
    t67 = (t66 + 4);
    t41 = *((unsigned int *)t67);
    t42 = (~(t41));
    t43 = *((unsigned int *)t66);
    t44 = (t43 & t42);
    t45 = (t44 & 1U);
    if (t45 != 0)
        goto LAB63;

LAB64:    if (*((unsigned int *)t67) != 0)
        goto LAB65;

LAB66:    t48 = *((unsigned int *)t22);
    t49 = *((unsigned int *)t76);
    t50 = (t48 & t49);
    *((unsigned int *)t84) = t50;
    t75 = (t22 + 4);
    t77 = (t76 + 4);
    t85 = (t84 + 4);
    t51 = *((unsigned int *)t75);
    t52 = *((unsigned int *)t77);
    t53 = (t51 | t52);
    *((unsigned int *)t85) = t53;
    t55 = *((unsigned int *)t85);
    t56 = (t55 != 0);
    if (t56 == 1)
        goto LAB67;

LAB68:
LAB69:    goto LAB57;

LAB59:    t65 = (t66 + 4);
    *((unsigned int *)t66) = 1;
    *((unsigned int *)t65) = 1;
    goto LAB61;

LAB63:    *((unsigned int *)t76) = 1;
    goto LAB66;

LAB65:    t74 = (t76 + 4);
    *((unsigned int *)t76) = 1;
    *((unsigned int *)t74) = 1;
    goto LAB66;

LAB67:    t57 = *((unsigned int *)t84);
    t58 = *((unsigned int *)t85);
    *((unsigned int *)t84) = (t57 | t58);
    t86 = (t22 + 4);
    t87 = (t76 + 4);
    t59 = *((unsigned int *)t22);
    t68 = (~(t59));
    t69 = *((unsigned int *)t86);
    t70 = (~(t69));
    t71 = *((unsigned int *)t76);
    t72 = (~(t71));
    t73 = *((unsigned int *)t87);
    t78 = (~(t73));
    t46 = (t68 & t70);
    t47 = (t72 & t78);
    t79 = (~(t46));
    t80 = (~(t47));
    t81 = *((unsigned int *)t85);
    *((unsigned int *)t85) = (t81 & t79);
    t82 = *((unsigned int *)t85);
    *((unsigned int *)t85) = (t82 & t80);
    t83 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t83 & t79);
    t88 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t88 & t80);
    goto LAB69;

LAB70:    xsi_set_current_line(61, ng0);

LAB73:    xsi_set_current_line(62, ng0);
    t95 = (t0 + 2760);
    t96 = (t95 + 36U);
    t100 = *((char **)t96);
    t101 = (t100 + 4);
    t98 = *((unsigned int *)t101);
    t99 = (~(t98));
    t102 = *((unsigned int *)t100);
    t103 = (t102 & t99);
    t104 = (t103 != 0);
    if (t104 > 0)
        goto LAB74;

LAB75:    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 1612U);
    t4 = *((char **)t3);
    xsi_vlogtype_concat(t11, 32, 32, 2U, t4, 30, t2, 2);
    t3 = (t0 + 2116);
    xsi_vlogvar_assign_value(t3, t11, 0, 0, 32);

LAB76:    goto LAB72;

LAB74:    xsi_set_current_line(63, ng0);
    t106 = ((char*)((ng7)));
    t107 = (t0 + 1612U);
    t108 = *((char **)t107);
    t107 = ((char*)((ng9)));
    memset(t109, 0, 8);
    xsi_vlog_unsigned_minus(t109, 32, t108, 30, t107, 32);
    xsi_vlogtype_concat(t105, 34, 34, 2U, t109, 32, t106, 2);
    t110 = (t0 + 2116);
    xsi_vlogvar_assign_value(t110, t105, 0, 0, 32);
    goto LAB76;

LAB77:    xsi_set_current_line(69, ng0);

LAB80:    xsi_set_current_line(70, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t0 + 2300);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 1);
    xsi_set_current_line(71, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2760);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB79;

}

static void Cont_77_2(char *t0)
{
    char t3[8];
    char t8[8];
    char t49[8];
    char t81[8];
    char t92[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    int t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    char *t53;
    char *t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    char *t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    int t73;
    int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;
    char *t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    char *t106;
    char *t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    int t116;
    int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    char *t124;
    char *t125;
    char *t126;
    char *t127;
    char *t128;
    unsigned int t129;
    unsigned int t130;
    char *t131;
    unsigned int t132;
    unsigned int t133;
    char *t134;
    unsigned int t135;
    unsigned int t136;
    char *t137;

LAB0:    t1 = (t0 + 3572U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 2208);
    t4 = (t2 + 36U);
    t5 = *((char **)t4);
    t6 = (t0 + 1152U);
    t7 = *((char **)t6);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t7);
    t11 = (t9 & t10);
    *((unsigned int *)t8) = t11;
    t6 = (t5 + 4);
    t12 = (t7 + 4);
    t13 = (t8 + 4);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t12);
    t16 = (t14 | t15);
    *((unsigned int *)t13) = t16;
    t17 = *((unsigned int *)t13);
    t18 = (t17 != 0);
    if (t18 == 1)
        goto LAB4;

LAB5:
LAB6:    memset(t3, 0, 8);
    t39 = (t8 + 4);
    t40 = *((unsigned int *)t39);
    t41 = (~(t40));
    t42 = *((unsigned int *)t8);
    t43 = (t42 & t41);
    t44 = (t43 & 63U);
    if (t44 != 0)
        goto LAB7;

LAB8:    if (*((unsigned int *)t39) != 0)
        goto LAB9;

LAB10:    t46 = (t0 + 2392);
    t47 = (t46 + 36U);
    t48 = *((char **)t47);
    t50 = *((unsigned int *)t3);
    t51 = *((unsigned int *)t48);
    t52 = (t50 & t51);
    *((unsigned int *)t49) = t52;
    t53 = (t3 + 4);
    t54 = (t48 + 4);
    t55 = (t49 + 4);
    t56 = *((unsigned int *)t53);
    t57 = *((unsigned int *)t54);
    t58 = (t56 | t57);
    *((unsigned int *)t55) = t58;
    t59 = *((unsigned int *)t55);
    t60 = (t59 != 0);
    if (t60 == 1)
        goto LAB11;

LAB12:
LAB13:    t82 = (t0 + 2300);
    t83 = (t82 + 36U);
    t84 = *((char **)t83);
    memset(t81, 0, 8);
    t85 = (t84 + 4);
    t86 = *((unsigned int *)t85);
    t87 = (~(t86));
    t88 = *((unsigned int *)t84);
    t89 = (t88 & t87);
    t90 = (t89 & 1U);
    if (t90 != 0)
        goto LAB17;

LAB15:    if (*((unsigned int *)t85) == 0)
        goto LAB14;

LAB16:    t91 = (t81 + 4);
    *((unsigned int *)t81) = 1;
    *((unsigned int *)t91) = 1;

LAB17:    t93 = *((unsigned int *)t49);
    t94 = *((unsigned int *)t81);
    t95 = (t93 & t94);
    *((unsigned int *)t92) = t95;
    t96 = (t49 + 4);
    t97 = (t81 + 4);
    t98 = (t92 + 4);
    t99 = *((unsigned int *)t96);
    t100 = *((unsigned int *)t97);
    t101 = (t99 | t100);
    *((unsigned int *)t98) = t101;
    t102 = *((unsigned int *)t98);
    t103 = (t102 != 0);
    if (t103 == 1)
        goto LAB18;

LAB19:
LAB20:    t124 = (t0 + 4124);
    t125 = (t124 + 32U);
    t126 = *((char **)t125);
    t127 = (t126 + 40U);
    t128 = *((char **)t127);
    memset(t128, 0, 8);
    t129 = 1U;
    t130 = t129;
    t131 = (t92 + 4);
    t132 = *((unsigned int *)t92);
    t129 = (t129 & t132);
    t133 = *((unsigned int *)t131);
    t130 = (t130 & t133);
    t134 = (t128 + 4);
    t135 = *((unsigned int *)t128);
    *((unsigned int *)t128) = (t135 | t129);
    t136 = *((unsigned int *)t134);
    *((unsigned int *)t134) = (t136 | t130);
    xsi_driver_vfirst_trans(t124, 0, 0);
    t137 = (t0 + 4064);
    *((int *)t137) = 1;

LAB1:    return;
LAB4:    t19 = *((unsigned int *)t8);
    t20 = *((unsigned int *)t13);
    *((unsigned int *)t8) = (t19 | t20);
    t21 = (t5 + 4);
    t22 = (t7 + 4);
    t23 = *((unsigned int *)t5);
    t24 = (~(t23));
    t25 = *((unsigned int *)t21);
    t26 = (~(t25));
    t27 = *((unsigned int *)t7);
    t28 = (~(t27));
    t29 = *((unsigned int *)t22);
    t30 = (~(t29));
    t31 = (t24 & t26);
    t32 = (t28 & t30);
    t33 = (~(t31));
    t34 = (~(t32));
    t35 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t35 & t33);
    t36 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t36 & t34);
    t37 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t37 & t33);
    t38 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t38 & t34);
    goto LAB6;

LAB7:    *((unsigned int *)t3) = 1;
    goto LAB10;

LAB9:    t45 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t45) = 1;
    goto LAB10;

LAB11:    t61 = *((unsigned int *)t49);
    t62 = *((unsigned int *)t55);
    *((unsigned int *)t49) = (t61 | t62);
    t63 = (t3 + 4);
    t64 = (t48 + 4);
    t65 = *((unsigned int *)t3);
    t66 = (~(t65));
    t67 = *((unsigned int *)t63);
    t68 = (~(t67));
    t69 = *((unsigned int *)t48);
    t70 = (~(t69));
    t71 = *((unsigned int *)t64);
    t72 = (~(t71));
    t73 = (t66 & t68);
    t74 = (t70 & t72);
    t75 = (~(t73));
    t76 = (~(t74));
    t77 = *((unsigned int *)t55);
    *((unsigned int *)t55) = (t77 & t75);
    t78 = *((unsigned int *)t55);
    *((unsigned int *)t55) = (t78 & t76);
    t79 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t79 & t75);
    t80 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t80 & t76);
    goto LAB13;

LAB14:    *((unsigned int *)t81) = 1;
    goto LAB17;

LAB18:    t104 = *((unsigned int *)t92);
    t105 = *((unsigned int *)t98);
    *((unsigned int *)t92) = (t104 | t105);
    t106 = (t49 + 4);
    t107 = (t81 + 4);
    t108 = *((unsigned int *)t49);
    t109 = (~(t108));
    t110 = *((unsigned int *)t106);
    t111 = (~(t110));
    t112 = *((unsigned int *)t81);
    t113 = (~(t112));
    t114 = *((unsigned int *)t107);
    t115 = (~(t114));
    t116 = (t109 & t111);
    t117 = (t113 & t115);
    t118 = (~(t116));
    t119 = (~(t117));
    t120 = *((unsigned int *)t98);
    *((unsigned int *)t98) = (t120 & t118);
    t121 = *((unsigned int *)t98);
    *((unsigned int *)t98) = (t121 & t119);
    t122 = *((unsigned int *)t92);
    *((unsigned int *)t92) = (t122 & t118);
    t123 = *((unsigned int *)t92);
    *((unsigned int *)t92) = (t123 & t119);
    goto LAB20;

}

static void Cont_78_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 3716U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(78, ng0);
    t2 = (t0 + 2116);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 4160);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t4, 8);
    xsi_driver_vfirst_trans(t5, 0, 31);
    t10 = (t0 + 4072);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Cont_79_4(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t20[8];
    char t36[8];
    char t37[8];
    char t40[8];
    char t54[8];
    char t71[8];
    char t72[8];
    char t75[8];
    char t96[8];
    char t97[8];
    char t100[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t38;
    char *t39;
    char *t41;
    char *t42;
    char *t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    char *t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    char *t73;
    char *t74;
    char *t76;
    char *t77;
    char *t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    char *t84;
    char *t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    char *t89;
    char *t90;
    char *t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t98;
    char *t99;
    char *t101;
    char *t102;
    char *t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    char *t109;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    char *t114;
    char *t115;
    char *t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    char *t121;
    char *t122;
    char *t123;
    char *t124;
    char *t125;
    char *t126;
    char *t127;

LAB0:    t1 = (t0 + 3860U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(79, ng0);
    t2 = (t0 + 1336U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng5)));
    memset(t6, 0, 8);
    if (*((unsigned int *)t5) != *((unsigned int *)t2))
        goto LAB6;

LAB4:    t7 = (t5 + 4);
    t8 = (t2 + 4);
    if (*((unsigned int *)t7) != *((unsigned int *)t8))
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB6:    memset(t4, 0, 8);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t9);
    t11 = (~(t10));
    t12 = *((unsigned int *)t6);
    t13 = (t12 & t11);
    t14 = (t13 & 1U);
    if (t14 != 0)
        goto LAB7;

LAB8:    if (*((unsigned int *)t9) != 0)
        goto LAB9;

LAB10:    t16 = (t4 + 4);
    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t16);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB11;

LAB12:    t32 = *((unsigned int *)t4);
    t33 = (~(t32));
    t34 = *((unsigned int *)t16);
    t35 = (t33 || t34);
    if (t35 > 0)
        goto LAB13;

LAB14:    if (*((unsigned int *)t16) > 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t4) > 0)
        goto LAB17;

LAB18:    memcpy(t3, t36, 8);

LAB19:    t122 = (t0 + 4196);
    t123 = (t122 + 32U);
    t124 = *((char **)t123);
    t125 = (t124 + 40U);
    t126 = *((char **)t125);
    memcpy(t126, t3, 8);
    xsi_driver_vfirst_trans(t122, 0, 31);
    t127 = (t0 + 4080);
    *((int *)t127) = 1;

LAB1:    return;
LAB7:    *((unsigned int *)t4) = 1;
    goto LAB10;

LAB9:    t15 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t15) = 1;
    goto LAB10;

LAB11:    t21 = (t0 + 2392);
    t22 = (t21 + 36U);
    t23 = *((char **)t22);
    t24 = (t0 + 2300);
    t25 = (t24 + 36U);
    t26 = *((char **)t25);
    t27 = ((char*)((ng7)));
    t28 = (t0 + 2208);
    t29 = (t28 + 36U);
    t30 = *((char **)t29);
    t31 = ((char*)((ng7)));
    xsi_vlogtype_concat(t20, 32, 32, 5U, t31, 16, t30, 6, t27, 8, t26, 1, t23, 1);
    goto LAB12;

LAB13:    t38 = (t0 + 1336U);
    t39 = *((char **)t38);
    t38 = ((char*)((ng10)));
    memset(t40, 0, 8);
    if (*((unsigned int *)t39) != *((unsigned int *)t38))
        goto LAB22;

LAB20:    t41 = (t39 + 4);
    t42 = (t38 + 4);
    if (*((unsigned int *)t41) != *((unsigned int *)t42))
        goto LAB22;

LAB21:    *((unsigned int *)t40) = 1;

LAB22:    memset(t37, 0, 8);
    t43 = (t40 + 4);
    t44 = *((unsigned int *)t43);
    t45 = (~(t44));
    t46 = *((unsigned int *)t40);
    t47 = (t46 & t45);
    t48 = (t47 & 1U);
    if (t48 != 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t43) != 0)
        goto LAB25;

LAB26:    t50 = (t37 + 4);
    t51 = *((unsigned int *)t37);
    t52 = *((unsigned int *)t50);
    t53 = (t51 || t52);
    if (t53 > 0)
        goto LAB27;

LAB28:    t67 = *((unsigned int *)t37);
    t68 = (~(t67));
    t69 = *((unsigned int *)t50);
    t70 = (t68 || t69);
    if (t70 > 0)
        goto LAB29;

LAB30:    if (*((unsigned int *)t50) > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t37) > 0)
        goto LAB33;

LAB34:    memcpy(t36, t71, 8);

LAB35:    goto LAB14;

LAB15:    xsi_vlog_unsigned_bit_combine(t3, 32, t20, 32, t36, 32);
    goto LAB19;

LAB17:    memcpy(t3, t20, 8);
    goto LAB19;

LAB23:    *((unsigned int *)t37) = 1;
    goto LAB26;

LAB25:    t49 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t49) = 1;
    goto LAB26;

LAB27:    t55 = ((char*)((ng7)));
    t56 = (t0 + 2668);
    t57 = (t56 + 36U);
    t58 = *((char **)t57);
    t59 = ((char*)((ng7)));
    t60 = (t0 + 2576);
    t61 = (t60 + 36U);
    t62 = *((char **)t61);
    t63 = ((char*)((ng7)));
    t64 = (t0 + 2760);
    t65 = (t64 + 36U);
    t66 = *((char **)t65);
    xsi_vlogtype_concat(t54, 32, 32, 6U, t66, 1, t63, 15, t62, 6, t59, 3, t58, 5, t55, 2);
    goto LAB28;

LAB29:    t73 = (t0 + 1336U);
    t74 = *((char **)t73);
    t73 = ((char*)((ng6)));
    memset(t75, 0, 8);
    if (*((unsigned int *)t74) != *((unsigned int *)t73))
        goto LAB38;

LAB36:    t76 = (t74 + 4);
    t77 = (t73 + 4);
    if (*((unsigned int *)t76) != *((unsigned int *)t77))
        goto LAB38;

LAB37:    *((unsigned int *)t75) = 1;

LAB38:    memset(t72, 0, 8);
    t78 = (t75 + 4);
    t79 = *((unsigned int *)t78);
    t80 = (~(t79));
    t81 = *((unsigned int *)t75);
    t82 = (t81 & t80);
    t83 = (t82 & 1U);
    if (t83 != 0)
        goto LAB39;

LAB40:    if (*((unsigned int *)t78) != 0)
        goto LAB41;

LAB42:    t85 = (t72 + 4);
    t86 = *((unsigned int *)t72);
    t87 = *((unsigned int *)t85);
    t88 = (t86 || t87);
    if (t88 > 0)
        goto LAB43;

LAB44:    t92 = *((unsigned int *)t72);
    t93 = (~(t92));
    t94 = *((unsigned int *)t85);
    t95 = (t93 || t94);
    if (t95 > 0)
        goto LAB45;

LAB46:    if (*((unsigned int *)t85) > 0)
        goto LAB47;

LAB48:    if (*((unsigned int *)t72) > 0)
        goto LAB49;

LAB50:    memcpy(t71, t96, 8);

LAB51:    goto LAB30;

LAB31:    xsi_vlog_unsigned_bit_combine(t36, 32, t54, 32, t71, 32);
    goto LAB35;

LAB33:    memcpy(t36, t54, 8);
    goto LAB35;

LAB39:    *((unsigned int *)t72) = 1;
    goto LAB42;

LAB41:    t84 = (t72 + 4);
    *((unsigned int *)t72) = 1;
    *((unsigned int *)t84) = 1;
    goto LAB42;

LAB43:    t89 = (t0 + 2116);
    t90 = (t89 + 36U);
    t91 = *((char **)t90);
    goto LAB44;

LAB45:    t98 = (t0 + 1336U);
    t99 = *((char **)t98);
    t98 = ((char*)((ng11)));
    memset(t100, 0, 8);
    if (*((unsigned int *)t99) != *((unsigned int *)t98))
        goto LAB54;

LAB52:    t101 = (t99 + 4);
    t102 = (t98 + 4);
    if (*((unsigned int *)t101) != *((unsigned int *)t102))
        goto LAB54;

LAB53:    *((unsigned int *)t100) = 1;

LAB54:    memset(t97, 0, 8);
    t103 = (t100 + 4);
    t104 = *((unsigned int *)t103);
    t105 = (~(t104));
    t106 = *((unsigned int *)t100);
    t107 = (t106 & t105);
    t108 = (t107 & 1U);
    if (t108 != 0)
        goto LAB55;

LAB56:    if (*((unsigned int *)t103) != 0)
        goto LAB57;

LAB58:    t110 = (t97 + 4);
    t111 = *((unsigned int *)t97);
    t112 = *((unsigned int *)t110);
    t113 = (t111 || t112);
    if (t113 > 0)
        goto LAB59;

LAB60:    t117 = *((unsigned int *)t97);
    t118 = (~(t117));
    t119 = *((unsigned int *)t110);
    t120 = (t118 || t119);
    if (t120 > 0)
        goto LAB61;

LAB62:    if (*((unsigned int *)t110) > 0)
        goto LAB63;

LAB64:    if (*((unsigned int *)t97) > 0)
        goto LAB65;

LAB66:    memcpy(t96, t121, 8);

LAB67:    goto LAB46;

LAB47:    xsi_vlog_unsigned_bit_combine(t71, 32, t91, 32, t96, 32);
    goto LAB51;

LAB49:    memcpy(t71, t91, 8);
    goto LAB51;

LAB55:    *((unsigned int *)t97) = 1;
    goto LAB58;

LAB57:    t109 = (t97 + 4);
    *((unsigned int *)t97) = 1;
    *((unsigned int *)t109) = 1;
    goto LAB58;

LAB59:    t114 = (t0 + 2484);
    t115 = (t114 + 36U);
    t116 = *((char **)t115);
    goto LAB60;

LAB61:    t121 = ((char*)((ng3)));
    goto LAB62;

LAB63:    xsi_vlog_unsigned_bit_combine(t96, 32, t116, 32, t121, 32);
    goto LAB67;

LAB65:    memcpy(t96, t116, 8);
    goto LAB67;

}


extern void work_m_00000000000356089823_3975733304_init()
{
	static char *pe[] = {(void *)Initial_35_0,(void *)Always_40_1,(void *)Cont_77_2,(void *)Cont_78_3,(void *)Cont_79_4};
	xsi_register_didat("work_m_00000000000356089823_3975733304", "isim/mips_isim_beh.exe.sim/work/m_00000000000356089823_3975733304.didat");
	xsi_register_executes(pe);
}
